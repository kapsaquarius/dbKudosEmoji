package com.codingchallenge.dbKudosEmoji;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbKudosEmojiApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.codingchallenge.dbKudosEmoji.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;

import com.codingchallenge.dbKudosEmoji.models.badgeDetailsModel;
import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.models.successResponse;
import com.codingchallenge.dbKudosEmoji.utils.dbConnector;

@Service
public class profilePageService {
	
	static Logger logger = Logger.getLogger(marketplaceService.class.getName());
	String url = "jdbc:mysql://localhost:3306/employee";
	String driver = "com.mysql.jdbc.Driver";
	private String username = "root";
	private String password = "root"; 
	
	public employeeModel getProfile(String email) {

		Connection conn = null;
		try
	    {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully!");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection();
			if (conn == null) {
				logger.info("Error Connecting!");
	
			}
			logger.info("Connected to DB!!");
	
			String query = "SELECT * FROM Employee WHERE email=" + "'"+ email+ "'";
			
			
			System.out.println(query);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			if(rs.next() == true) {
       
		     return new employeeModel(rs.getString("name"),rs.getString("dept"),rs.getString("email"),rs.getString("image_url"),
		     rs.getInt("current_kudos"),rs.getInt("kudos_spend"));
				
			}
			
	        st.close();


	      
	    }
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB!!");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return new employeeModel("","","","",0,0);

	}

}

package com.codingchallenge.dbKudosEmoji.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbConnector {
	
	String url ="";
	String username="";
	String password= "";
	
	public dbConnector(String url,String username,String password) {
		this.url = url;
		this.username = username;
		this.password = password;
	}
	
	public Connection getConnection(){
		
		try {
			Connection connection = DriverManager.getConnection(url,username,password);
			return connection;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
			
}

}

package com.codingchallenge.dbKudosEmoji.models;

public class employeeModel {
	String name;
	String dept;
	String email;
	String image_url;
	int current_kudos;
	int kudos_spent;
	
	public employeeModel(String name,String dept,String email,String image_url,int current_kudos,int kudos_spent) {
		this.name = name;
		this.email = email;
		this.dept = dept;
		this.image_url = image_url;
		this.current_kudos = current_kudos;
		this.kudos_spent = kudos_spent;
 	}
	
}

package com.codingchallenge.dbKudosEmoji.models;

public class cart {
	String email;
	int badge_id;
}

package com.codingchallenge.dbKudosEmoji.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;

import com.codingchallenge.dbKudosEmoji.models.badgeDetailsModel;
import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.utils.dbConnector;

@Service
public class marketplaceService {
	
	static Logger logger = Logger.getLogger(marketplaceService.class.getName());
	String url = "jdbc:mysql://localhost:3306/employee";
	String driver = "com.mysql.jdbc.Driver";
	private String username = "root";
	private String password = "root"; 
	

	
	public List<badgeDetailsModel> getBadgesByFilter(String filter) {
		Connection conn = null;
		List<badgeDetailsModel> badges = new ArrayList<>();
		String query;
		try
	    {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection();
			if (conn == null) {
				logger.info("Error Connecting");

			}
			logger.info("Connected to DB");
			logger.info(filter);
			
			

			if (filter.equals("all")) {
				 query = "SELECT name,image_url,kudos_points_required from Badge_Details";
				
			}
			else if(filter.equals("bronze")) {
				query = "SELECT name,image_url,kudos_points_required from Badge_Details where level =" + "'bronze'";
				
			}
			else if(filter.equals("silver")) {
				query = "SELECT name,image_url,kudos_points_required from Badge_Details where level =" + "'silver'";				
			}
			else if(filter.equals("gold")) {
				query = "SELECT name,image_url,kudos_points_required from Badge_Details where level =" + "'gold'";				
			}
			else if (filter.equals("platinum")){
				query = "SELECT name,image_url,kudos_points_required from Badge_Details where level =" + "'platinum'";			
			}
			else {
				return badges;
			}

			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
	      
	  
		
	        while (rs.next())
	        {
		        String name = rs.getString("name");
		        String imgUrl = rs.getString("image_url");
		        int pointsReq = rs.getInt("kudos_points_required");
		        
		        System.out.println(name);
		       
		        badges.add(new badgeDetailsModel(name,imgUrl,pointsReq));
		        
	     
	        }
	        
	        System.out.println(badges);
	        st.close();
	      
	      
	       
	    }
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return badges;
		
	}

}

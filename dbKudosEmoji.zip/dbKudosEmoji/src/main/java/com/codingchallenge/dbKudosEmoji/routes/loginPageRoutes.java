package com.codingchallenge.dbKudosEmoji.routes;


import java.awt.PageAttributes.MediaType;
import java.io.IOException;

import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.logging.Log;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.models.successResponse;
import com.codingchallenge.dbKudosEmoji.services.leaderboardService;
import com.codingchallenge.dbKudosEmoji.services.loginService;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin(origins = { "http://localhost:3000/" })
@RestController
public class loginPageRoutes {
	
	static Logger logger = Logger.getLogger(leaderboardService.class.getName());
	String url = "jdbc:mysql://localhost:3306/employee";
	String driver = "com.mysql.jdbc.Driver";
	successResponse sr ;
	
	
	@PostMapping(path = "login")
	public ResponseEntity<successResponse> login(@RequestBody String email) {

		
		try {
		     JSONObject jsonObject = new JSONObject(email);
		 	 System.out.println(jsonObject);
		 	 		 	
		 	 String em = (String) jsonObject.get("email");
			
			 loginService ls = new loginService();
			 sr = ls.login(em);
			 
			 try
			    {
				    ObjectMapper mapper = new ObjectMapper();
				    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
				    if (sr.getStatus().equals("false")) {
				    	return new ResponseEntity<successResponse>(sr,HttpStatus.UNAUTHORIZED);
				    }
				    	
				    return new ResponseEntity<successResponse>(sr,HttpStatus.OK);
				    
			    }
		        catch(Exception ex)
		        {
		            ex.printStackTrace();
		        }
				
		
		}catch (JSONException err){
		     logger.info("Error");
		}
		
		return new ResponseEntity<successResponse>(sr,HttpStatus.UNAUTHORIZED);
		
		
		
	}

	
	
	

	
}
	
	
	

	
	


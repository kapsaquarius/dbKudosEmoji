package com.codingchallenge.dbKudosEmoji.routes;

import java.io.IOException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.services.leaderboardService;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin(origins = { "http://localhost:3000" })
@RestController
public class leaderboardRoutes {
	
	@GetMapping("/getLeaderBoard")
	public ResponseEntity<String> getLeaderBoard() {
		leaderboardService ls = new leaderboardService();
		List<employeeModel> emps = ls.getLeaderboard();

		try
	    {
	    
		    ObjectMapper mapper = new ObjectMapper();
		    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		    String json=mapper.writeValueAsString(emps);
		    if(json.equals("[]")) {
		    	return new ResponseEntity<String>(json,HttpStatus.OK);
		    	
		    }
		    return new ResponseEntity<String>(json,HttpStatus.OK);
	    }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
		
    	return new ResponseEntity<String>("[]",HttpStatus.OK);

		
	}

}

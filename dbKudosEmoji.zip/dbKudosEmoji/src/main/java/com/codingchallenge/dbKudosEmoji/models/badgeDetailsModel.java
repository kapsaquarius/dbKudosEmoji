package com.codingchallenge.dbKudosEmoji.models;

public class badgeDetailsModel {
	
	
//	int badge_id;
	String name;
	String image_url;
	int kudos_points_required;
//	String level;
	
	public badgeDetailsModel(String name, String image_url, int kudos_points_required) {
		this.name = name;
		this.image_url = image_url;
		this.kudos_points_required = kudos_points_required;
	}

	
}



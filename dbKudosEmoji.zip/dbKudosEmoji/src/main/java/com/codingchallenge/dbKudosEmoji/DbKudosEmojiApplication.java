package com.codingchallenge.dbKudosEmoji;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbKudosEmojiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbKudosEmojiApplication.class, args);
	}

}

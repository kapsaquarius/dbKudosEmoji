package com.codingchallenge.dbKudosEmoji.routes;

import java.io.IOException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codingchallenge.dbKudosEmoji.models.badgeDetailsModel;
import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.services.marketplaceService;
import com.codingchallenge.dbKudosEmoji.services.profilePageService;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin(origins = { "http://localhost:3000" })
@RestController
public class profilePageRoutes {
	
	@GetMapping("/getProfile")
	public ResponseEntity<String> getProfile(@RequestParam String email){
		
		profilePageService ps = new profilePageService();
		
		employeeModel em = ps.getProfile(email);
		
	
		try
	    {
		    ObjectMapper mapper = new ObjectMapper();
		    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		    String json=mapper.writeValueAsString(em);
		    if (em.getName().equals("")) {
		    	return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		    }
		    return new ResponseEntity<String>(json,HttpStatus.OK);
	    }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
		
		return new ResponseEntity<String>(HttpStatus.NOT_FOUND);

		
	}
	

}

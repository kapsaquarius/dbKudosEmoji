package com.codingchallenge.dbKudosEmoji.models;

public class successResponse {
	
	String success;
	
	public successResponse(String status) {
		this.success = status;
	}
	
	public String getStatus() {
		return success;
	}

}

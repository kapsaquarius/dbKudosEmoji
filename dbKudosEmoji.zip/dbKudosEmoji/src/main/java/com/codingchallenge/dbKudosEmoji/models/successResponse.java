package com.codingchallenge.dbKudosEmoji.models;

public class successResponse {
	
	String success;
	int statusCode;
	
	public successResponse(String status,int statusCode) {
		this.success = status;
		this.statusCode = statusCode;
	}

}

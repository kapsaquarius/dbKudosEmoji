package com.codingchallenge.dbKudosEmoji;

import java.sql.Connection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.utils.dbConnector;


import com.codingchallenge.dbKudosEmoji.models.badgeDetailsModel;
import com.codingchallenge.dbKudosEmoji.models.badgesBoughtModel;
import com.codingchallenge.dbKudosEmoji.models.cart;
@SpringBootApplication
@Component
@EnableAutoConfiguration
public class DbKudosEmojiApplication {

	public static void main(String[] args) {
		

		
		dbConnector dbconnect1 =new dbConnector("jdbc:mysql://localhost:3306","root","root");
		dbconnect1.getConnection1();
		
		ConfigurableApplicationContext applicationContext = SpringApplication.run(DbKudosEmojiApplication.class, args);

		
		dbConnector dbconnect =new dbConnector("jdbc:mysql://localhost:3306","root","root");
		dbconnect.getConnection();
		
	}

}
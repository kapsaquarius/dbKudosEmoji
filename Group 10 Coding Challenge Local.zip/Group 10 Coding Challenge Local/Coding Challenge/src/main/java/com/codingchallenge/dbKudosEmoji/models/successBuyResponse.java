package com.codingchallenge.dbKudosEmoji.models;

public class successBuyResponse {
	
	String success;
	public successBuyResponse(String success) {
		this.success = success;
	}
	public String getStatus() {
		return success;
	}

}

package com.codingchallenge.dbKudosEmoji.models;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;

//import com.codingchallenge.dbKudosEmoji.schemas.Employee;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.codingchallenge.dbKudosEmoji.schemas.Badge;
import com.codingchallenge.dbKudosEmoji.schemas.Employee;


import javax.persistence.ForeignKey;




public class badgeDetailsModel extends Badge  {
	
    private String badge_id;
	private String name;
	private String image_url;
	private int kudos_points_required;
	private String level;
	
	public badgeDetailsModel(String id, String name, String image_url, int kudos_points_required, String level) {
		this.badge_id = id;
	
		this.name = name;
		this.image_url = image_url;
		this.kudos_points_required = kudos_points_required;
		this.level = level;
	}
	


	
}



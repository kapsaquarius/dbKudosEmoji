package com.codingchallenge.dbKudosEmoji.models;

public class successAddToCartModel {
	String success;
	public successAddToCartModel(String success) {
		this.success = success;
	}
	
	public String getStatus() {
		return success;
	}
}

package com.codingchallenge.dbKudosEmoji.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;

import com.codingchallenge.dbKudosEmoji.models.badgeDetailsModel;
import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.models.employeeProfileModel;
import com.codingchallenge.dbKudosEmoji.models.successLoginResponse;
import com.codingchallenge.dbKudosEmoji.utils.dbConnector;

@Service
public class profilePageService {
	
	static Logger logger = Logger.getLogger(profilePageService.class.getName());
	String url = "jdbc:mysql://localhost:3306/group10codingchallenge";
	String driver = "com.mysql.jdbc.Driver";
	private String username = "root";
	private String password = "root"; 
	public List<employeeProfileModel> getProfile(String email) {

		Connection conn = null;
		List<employeeProfileModel> eps = new ArrayList<>();
		try
	    {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully!");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			
			conn = dbconnect.getConnection2();
			if (conn == null) {
				logger.info("Error Connecting!");
	
			}
			logger.info("Connected to DB!!");
	
			String query = "SELECT Employee.name,Employee.dept,Employee.email,Employee.current_kudos,Employee.kudos_spend,Employee.image_url,\r\n"
					+ "Badge_Details.image_url,Badge_Details.level from  Employee,Badge_Details,Badges_Bought \r\n"
					+ "where Employee.email = Badges_Bought.email and Badge_Details.badge_id = Badges_Bought.badge_id and Employee.email="+"'"+email+"'";
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			if(rs.next()==false) {
				
				System.out.println("Hi");
				String q = "SELECT * from Employee where email="+"'"+email+"'";
				
				Statement st1 = conn.createStatement();
				ResultSet rs1 = st1.executeQuery(q);
				
				if(rs1.next()) {
					
					eps.add(new employeeProfileModel(rs1.getString("name"),rs1.getString("dept"),rs1.getString("email"),rs1.getString("image_url"),
						     rs1.getInt("current_kudos"),rs1.getInt("kudos_spend"),"","")) ;
				}

		        st1.close();
		        
		        conn.close();
					
				return eps;

			}
			
			Statement st2 = conn.createStatement();
			ResultSet rs2 = st.executeQuery(query);
			
			
			while(rs2.next()) {
				eps.add(new employeeProfileModel(rs2.getString("name"),rs2.getString("dept"),rs2.getString("email"),rs2.getString("image_url"),
				     rs2.getInt("current_kudos"),rs2.getInt("kudos_spend"),rs2.getString("image_url"),rs2.getString("level")));
				
			}
				
				
	        st.close();
	        st2.close();
				
		   
	    }
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB!!");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return eps;

	}

}

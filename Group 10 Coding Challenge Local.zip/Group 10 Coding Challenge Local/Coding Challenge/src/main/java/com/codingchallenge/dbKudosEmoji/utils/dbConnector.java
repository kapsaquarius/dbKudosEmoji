package com.codingchallenge.dbKudosEmoji.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
@EnableAutoConfiguration
public class dbConnector {
	
	String url ="";
	String username="";
	String password= "";
	
	public dbConnector(String url,String username,String password) {
		this.url = url;
		this.username = username;
		this.password = password;
	}
	
	public Connection getConnection() {
		try {
			Connection connection= DriverManager.getConnection(url+"/group10codingchallenge",username,password);
			Statement st = connection.createStatement();
			st.execute("use group10codingchallenge");
			
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Ramesh Mishra','RFT-PACE','ramesh-mishra@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/aguero.png',27,12)"+ "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Niti Sharma','DWS','niti-sharma@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/alexmorgan.png',16,2)" + "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Akhil Sreenath','PB','akhil-sreenath@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/iniesta.jpg',20,0)" + "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Hiral Nath','CB-IB','hiral-nath@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/marta.jpg',47,23)" + "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Rohan Kumar','RFT-Market Risk','rohan-kumar@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/lewandowski.jpg',11,3)" + "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Sujit Das','DWS','sujit-das@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/suarez.jpg',40,21)" + "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Rahul Khatav','CTO','rahul-khatav@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/neymar.jpg',5,0)" + "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Anjali Kumar','HR Legal','anjali-kumar@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/megan.jpg',23,20)" + "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Sukriti Dasgupta','RFT-PACE','sukriti-dasgupta@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/carlilloyd.jpg',17,10)" + "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			st.executeUpdate("insert into Employee (name, dept, email, image_url, current_kudos, kudos_spend)"+" values('Anoop Jain','CPT','anoop-jain@db.com','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Employees/messi.png',14,13)" + "on duplicate key update name =values(name), dept =values(dept),image_url=values(image_url),current_kudos=values(current_kudos),kudos_spend=values(kudos_spend)");
			
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B101','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/ambitious.png',50,'bronze','Ambitious')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"   );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B102','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/collaborator.png',500,'silver','Collaborator')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"      );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B103','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/contributor.png',1150,'gold','Contributor')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"  );
			
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B104','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/courageous.png',100,'bronze','Courageous')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"   );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B105','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/dependable.png',600,'silver','Dependable')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"      );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B106','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/developer.png',1250,'gold','Developer')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"  );
			
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B107','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/enthusiast.png',150,'bronze','Enthusiast')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"   );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B108','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/ideator.png',700,'silver','Ideator')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"      );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B109','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/influencer.png',1300,'gold','Influencer')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"  );
			
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B110','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/innovator.png',200,'bronze','Innovator')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"   );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B111','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/leader.png',750,'silver','Leader')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"      );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B112','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/motivator.png',1400,'gold','Motivator')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"  );
			
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B113','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/open%20minded.png',250,'bronze','Open-Minded')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"   );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B114','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/punctual.png',800,'silver','Punctual')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"      );
			st.executeUpdate("insert into Badge_Details (badge_id, image_url, kudos_points_required, level, name)"+" values('B115','https://storage.cloud.google.com/grads-coding-group-10.appspot.com/Badges/team%20player.png',1500,'gold','Team-Player')" + "on duplicate key update image_url=values(image_url),kudos_points_required=values(kudos_points_required),level = values(level),name=values(name)"  );
			return connection;
		}
		
		 catch (SQLException e) {
				e.printStackTrace();
		 }
		 return null;
		
	}

		
		

	
	public Connection getConnection1(){
		
		
		try {
			
			Connection connection = DriverManager.getConnection(url,username,password);
			Statement st = connection.createStatement();

			st.execute("create database group10codingchallenge");
			
			return connection;
			
		} 
		catch (SQLException e){
			System.out.println("");
			
		}
		return null;
			
	}
	
	public Connection getConnection2(){
		
		
		try {
			
			Connection connection = DriverManager.getConnection(url,username,password);
			
			return connection;
			
		} 
		catch (SQLException e){
			System.out.println("");
			
		}
		return null;
			
	}
	
	
	
}
		
	

package com.codingchallenge.dbKudosEmoji.routes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codingchallenge.dbKudosEmoji.models.badgeDetailsModel;
import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.models.employeeProfileModel;
import com.codingchallenge.dbKudosEmoji.services.marketplaceService;
import com.codingchallenge.dbKudosEmoji.services.profilePageService;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin(origins =  "*")
@RestController
public class profilePageRoutes {
	
	@GetMapping("/getProfile")
	public ResponseEntity<String> getProfile(@RequestParam String email){
		
		profilePageService ps = new profilePageService();
		List<employeeProfileModel> emps = ps.getProfile(email);
		
	
		try
	    {
		    ObjectMapper mapper = new ObjectMapper();
		    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		    String json=mapper.writeValueAsString(emps);

		    return new ResponseEntity<String>(json,HttpStatus.OK);
	    }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
		
		return new ResponseEntity<String>(HttpStatus.NOT_FOUND);

		
	}
	

}

package com.codingchallenge.dbKudosEmoji.schemas;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name =  "Employee")


public class Employee {
	
	@Id
	@Column(name = "email")
	private String email;
	private String name;
	private String dept;
	private String image_url;
	private int current_kudos;
	private int kudos_spend;
	
	@ManyToMany(cascade = CascadeType.PERSIST)
	@JoinTable(name = "Badges_Bought",
				joinColumns = @JoinColumn(name = "email"),
				inverseJoinColumns = @JoinColumn(name = "badge_id"))
	
	protected Set<Badge> badges = new HashSet<>(); 
	
	@ManyToMany(cascade = CascadeType.PERSIST)
	@JoinTable(name = "Cart",
				joinColumns = @JoinColumn(name = "email"),
				inverseJoinColumns = @JoinColumn(name = "badge_id"))
	
	protected Set<Badge> cart_badges =new HashSet<>();
	
	

	
	

}


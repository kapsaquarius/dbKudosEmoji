package com.codingchallenge.dbKudosEmoji.models;

public class badgesBoughtModel {
	String email;
	int badge_id;
}

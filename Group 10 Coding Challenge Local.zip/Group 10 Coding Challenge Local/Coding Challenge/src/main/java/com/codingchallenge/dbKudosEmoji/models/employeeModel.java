package com.codingchallenge.dbKudosEmoji.models;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;

//import com.codingchallenge.dbKudosEmoji.schemas.Employee;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

//import com.codingchallenge.dbKudosEmoji.schemas.Badge;
import com.codingchallenge.dbKudosEmoji.schemas.Employee;

import javax.persistence.ForeignKey;


public class employeeModel extends Employee {//extends Employee {
	
	
	private String name;
	private String dept;
	private String email;
	private String image_url;
	private int current_kudos;
	private int kudos_spend;
	
	public  employeeModel(String name,String dept,String email,String image_url,int current_kudos,int kudos_spent) {
		this.name = name;
		this.email = email;
		this.dept = dept;
		this.image_url = image_url;
		this.current_kudos = current_kudos;
		this.kudos_spend = kudos_spent;
 	}
	public String getName() {
		return name;
	}
	
	
	
	
	
	
}

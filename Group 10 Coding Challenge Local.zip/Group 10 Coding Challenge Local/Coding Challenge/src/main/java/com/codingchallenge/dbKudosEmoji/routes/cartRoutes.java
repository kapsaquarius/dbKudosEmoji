package com.codingchallenge.dbKudosEmoji.routes;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codingchallenge.dbKudosEmoji.models.cartModel;
import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.models.successAddToCartModel;
import com.codingchallenge.dbKudosEmoji.models.successBuyResponse;
import com.codingchallenge.dbKudosEmoji.models.successDeleteResponse;
import com.codingchallenge.dbKudosEmoji.models.successLoginResponse;
import com.codingchallenge.dbKudosEmoji.services.cartService;
import com.codingchallenge.dbKudosEmoji.services.leaderboardService;
import com.codingchallenge.dbKudosEmoji.services.loginService;
import com.codingchallenge.dbKudosEmoji.services.marketplaceService;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin(origins = "*")
@RestController
public class cartRoutes {
	
	static Logger logger = Logger.getLogger(leaderboardService.class.getName());
	successDeleteResponse sdr ;
	
	@PostMapping(path = "addBadgeToCart")
	public ResponseEntity<successAddToCartModel> addBadgeToCart(@RequestBody String email, String badge_id){
		
		cartService cs = new cartService();
		
		JSONObject jsonObject = new JSONObject(email);
	 	 		 	
	 	String em = (String) jsonObject.get("email");
	 	String bi = (String) jsonObject.get("badge_id");
		
		successAddToCartModel sobj = cs.addToCart(em, bi);
		
	
		try
	    {
		    ObjectMapper mapper = new ObjectMapper();
		    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		    
		    if(sobj.getStatus().equals("true")) {
			    return new ResponseEntity<successAddToCartModel>(sobj,HttpStatus.OK);
		    }

	
	    }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
		
		return new ResponseEntity<successAddToCartModel>(sobj,HttpStatus.NOT_FOUND);

		
	}
	
	
	@DeleteMapping(path = "removeBadgeFromCart")
	public ResponseEntity<successDeleteResponse> removeBadgeFromCart(@RequestParam String email,@RequestParam String badge_id) {
		
		cartService cs = new cartService();
		sdr = cs.removeBadgeFromCart(email, badge_id);
		try
		    {
			    ObjectMapper mapper = new ObjectMapper();
			    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
			    if (sdr.getStatus().equals("false")) {
			    	return new ResponseEntity<successDeleteResponse>(HttpStatus.NOT_FOUND);
			    	
			    }
			    	
			    return new ResponseEntity<successDeleteResponse>(sdr,HttpStatus.OK);
			    
		    }
	        catch(Exception ex)
	        {
	            ex.printStackTrace();
	        }
			
	

	
	return new ResponseEntity<successDeleteResponse>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping(path = "emptyCart")
	public ResponseEntity<successDeleteResponse> emptyCart(@RequestParam String email) {
		
		cartService cs = new cartService();
		sdr = cs.emptyCart(email);
		try
		    {
			    ObjectMapper mapper = new ObjectMapper();
			    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
			    if (sdr.getStatus().equals("false")) {
			    	return new ResponseEntity<successDeleteResponse>(HttpStatus.NOT_FOUND);
			    	
			    }
			    	
			    return new ResponseEntity<successDeleteResponse>(sdr,HttpStatus.OK);
			    
		    }
	        catch(Exception ex)
	        {
	            ex.printStackTrace();
	        }
			
	

	
	return new ResponseEntity<successDeleteResponse>(HttpStatus.NOT_FOUND);
		

	}

	@GetMapping("/getCart")
	public ResponseEntity<String> getCart(@RequestParam String email) {
		
	cartService cs = new cartService();
	List<cartModel> crt = cs.getCart(email);
	
	

	try
    {
    
	    ObjectMapper mapper = new ObjectMapper();
	    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    String json=mapper.writeValueAsString(crt);
	    if(json.equals("[]")) {
	    	return new ResponseEntity<String>(json,HttpStatus.NOT_FOUND);
	    	
	    }
	    return new ResponseEntity<String>(json,HttpStatus.OK);
    }
    catch(IOException ex)
    {
        ex.printStackTrace();
    }
    catch(Exception ex)
    {
        ex.printStackTrace();
    }
	
	return new ResponseEntity<String>("[]",HttpStatus.NOT_FOUND);
	}
	
	
	@PostMapping(path ="/buy")
	public ResponseEntity<successBuyResponse> buy(@RequestBody String email){
		successBuyResponse sbr ;
		try {
		     JSONObject jsonObject = new JSONObject(email);
		 	 		 	
		 	 String em = (String) jsonObject.get("email");
			
			 cartService cs = new cartService();
			 sbr = cs.buy(em);
			 
			 try
			    {
				    ObjectMapper mapper = new ObjectMapper();
				    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
				    if (sbr.getStatus().equals("false")) {
				    	return new ResponseEntity<successBuyResponse>(HttpStatus.NOT_FOUND);
				    }
				    	
				    return new ResponseEntity<successBuyResponse>(sbr,HttpStatus.OK);
				    
			    }
		        catch(Exception ex)
		        {
		            ex.printStackTrace();
		        }
				
		
		}catch (JSONException err){
		     logger.info("Error");
		}
		
		return new ResponseEntity<successBuyResponse>(HttpStatus.NOT_FOUND);
		
		
	}
}
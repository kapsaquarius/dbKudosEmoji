package com.codingchallenge.dbKudosEmoji.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;

import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.utils.dbConnector;

@Service
public class leaderboardService{
	
	static Logger logger = Logger.getLogger(leaderboardService.class.getName());
	String url = "jdbc:mysql://localhost:3306/group10codingchallenge";
	String driver = "com.mysql.jdbc.Driver";
	private String username = "root";
	private String password = "root"; 
	
	

	
	public List<employeeModel> getLeaderboard() {
		Connection conn = null;
		List<employeeModel> employees = new ArrayList<>();
		try
	    {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection2();
			if (conn == null) {
				logger.info("Error Connecting");

			}
			logger.info("Connected to DB");

			String query = "SELECT * FROM Employee ORDER BY current_kudos DESC";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
	     
		
	        while (rs.next())
	        {
		        String name = rs.getString("name");
		        String dept = rs.getString("dept");
		        String email = rs.getString("email");
		        String imgUrl = rs.getString("image_url");
		        int current_kudos = rs.getInt("current_kudos");
		        int kudos_spent = rs.getInt("kudos_spend");
		        employeeModel e = new employeeModel(name, dept, email, imgUrl, current_kudos, kudos_spent);
		        employees.add(e);
		        
		        
		        
	     
	        }
	        st.close();
	      
	       
	    }
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return employees;
		
	}
	
	

	
	
}
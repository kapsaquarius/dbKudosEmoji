package com.codingchallenge.dbKudosEmoji.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.codingchallenge.dbKudosEmoji.models.cartModel;
import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.models.successAddToCartModel;
import com.codingchallenge.dbKudosEmoji.models.successBuyResponse;
import com.codingchallenge.dbKudosEmoji.models.successDeleteResponse;
import com.codingchallenge.dbKudosEmoji.models.successLoginResponse;
import com.codingchallenge.dbKudosEmoji.utils.dbConnector;

import java.util.ArrayList;
import java.util.List;

//import antlr.collections.List;

@Service
public class cartService {
	
	static Logger logger = Logger.getLogger(cartService.class.getName());
	String url = "jdbc:mysql://localhost:3306/group10codingchallenge";
	String driver = "com.mysql.jdbc.Driver";
	private String username = "root";
	private String password = "root"; 
	
	public successBuyResponse buy(String email) {
		
		Connection conn = null;
		String query;
		
		try {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection2();
			if (conn == null) {
				logger.info("Error Connecting");

			}
			logger.info("Connected to DB");
			
	
			
			query = "SELECT * from Badge_Details where badge_id in"
					+ "(SELECT badge_id from Cart where email="+"'"+email+"'"+")";
			
			Statement st = conn.createStatement();
			Statement st1 = conn.createStatement();
			Statement st2 = conn.createStatement();
			Statement st3 = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			if(!rs.next()) {
				return new successBuyResponse("false");

			}
			
			while(rs.next()) {
				int kudos = rs.getInt("kudos_points_required");
				System.out.println(kudos);
				String bid = rs.getString("badge_id");
				

				String q = "UPDATE Employee SET current_kudos = current_kudos-"+kudos+
						",kudos_spend=kudos_spend+"+kudos+" where email="+"'"+email+"'";   
						
				int status = st1.executeUpdate(q);
				
				if (status > 0) {
	                logger.info("Successfully Updated");
	            }
	             
	            else {
	            	 logger.info("Unsucessful Updation ");
	            }
				
				String q1 = "INSERT into Badges_Bought(email,badge_id) VALUES("+"'"+email+"',"+"'"+bid+"')";
				status = st2.executeUpdate(q1);
				
				if (status > 0) {
	                logger.info("Successfully Inserted");
	            }
	             
	            else {
	            	 logger.info("Unsucessful Insertion");
	            }
				
				String q2 = "DELETE from Cart where email ="+"'"+email+"' and "+"badge_id= "+"'"+bid+"'";
				status = st3.executeUpdate(q2);
				
				if (status > 0) {
	                logger.info("Successfully Deleted");
	            }
	             
	            else {
	            	 logger.info("Unsuccessful Deletion");
	            }
				
					
			}
			
			st.close();
			st1.close();
			st2.close();
			st3.close();
			
			
			return new successBuyResponse("true");
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return new successBuyResponse("false");
			
			
			
				
	}
	
	public successAddToCartModel addToCart(String email, String badge_id){
		Connection conn = null;
		String query;
		
		try {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection2();
			if (conn == null) {
				logger.info("Error Connecting");

			}
			logger.info("Connected to DB");
			
			System.out.println(email + "-"+ badge_id);
			
			query = "INSERT into Cart values"+"("+ "'"+email+"',"+"'"+badge_id+"'"+ ")";
			
			System.out.println(query);
			
			Statement st = conn.createStatement();
			
			int result = st.executeUpdate(query);
	  
	  
            if (result > 0) {
                logger.info("Successfully Inserted");
            }
             
            else {
            	 logger.info("Unsucessful Insertion ");
            }
            
            return new successAddToCartModel("true");
               	
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return new successAddToCartModel("false");
		
	}
	
	
	public successDeleteResponse removeBadgeFromCart(String email,String badge_id) {
		Connection conn = null;
		String query;
		
		try {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection2();
			if (conn == null) {
				logger.info("Error Connecting");

			}
			logger.info("Connected to DB");
			
			query = "DELETE from Cart where email="+"'"+email+"'" + "and " + "badge_id="+"'"+badge_id+"'";
		
			
			Statement st = conn.createStatement();
			
			int result = st.executeUpdate(query);
	  
	  
            if (result > 0) {
                logger.info("Successfully Deleted");
            }
             
            else {
            	 logger.info("Unsucessful Deletion ");
            }
            
            return new successDeleteResponse("true");
               	
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return new successDeleteResponse("false");
		
		
	}
	
	public successDeleteResponse emptyCart(String email) {
		Connection conn = null;
		String query;
		
		try {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection2();
			if (conn == null) {
				logger.info("Error Connecting");

			}
			logger.info("Connected to DB");
			
			query = "DELETE from Cart where email="+"'"+email+"'";
		
			
			Statement st = conn.createStatement();
			
			int result = st.executeUpdate(query);
	  
	  
            if (result > 0) {
                logger.info("Successfully Deleted");
            }
             
            else {
            	 logger.info("Unsucessful Deletion ");
            }
            
            return new successDeleteResponse("true");
               	
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return new successDeleteResponse("false");
		
		
	}
	
	public List<cartModel> getCart(String email) {
		Connection conn = null;
		List<cartModel> crt = new ArrayList<>();
		try
	    {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection2();
			if (conn == null) {
				logger.info("Error Connecting");

			}
			logger.info("Connected to DB");

			String query = "SELECT * FROM Badge_Details where badge_id in (SELECT badge_id from Badges_Bought where email="+"'"+email+"')";

			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

		
	        while (rs.next())
	        {
	        		String badge_id =rs.getString("badge_id");
	        	
	        		String name =rs.getString("name");
	        		String badgeid =rs.getString("badge_id");
	        		String image_url =rs.getString("image_url");
	        		String level =rs.getString("level");
	        		int points =rs.getInt("kudos_points_required");
	        		
	        		cartModel c = new cartModel(badgeid, name, image_url,level, points);
			        crt.add(c);
			       
	        	}
	        	
		        
		        
		        
		        
	
	        st.close();
	        
	        return crt;
	      
	       
	    }
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return crt;
	}

}
package com.codingchallenge.dbKudosEmoji.schemas;

import com.codingchallenge.dbKudosEmoji.schemas.Badge;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name =  "Badge_Details")


public class Badge {
	
	@Id
	@Column(name = "badge_id")
	private String badge_id;
	private String name;
	private String image_url;
	private int kudos_points_required;
	private String level;
	
	@ManyToMany(mappedBy = "badges")
	protected  Set<Employee> employees =new HashSet<>();
	
	@ManyToMany(mappedBy = "cart_badges")
	protected  Set<Employee> employee_cart =new HashSet<>();
	
	

}
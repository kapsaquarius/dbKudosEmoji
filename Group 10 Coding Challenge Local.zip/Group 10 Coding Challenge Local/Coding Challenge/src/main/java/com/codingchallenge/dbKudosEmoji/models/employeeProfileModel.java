package com.codingchallenge.dbKudosEmoji.models;

public class employeeProfileModel{
	
	private String name;
	private String dept;
	private String email;
	private String image_url;
	private int current_kudos;
	private int kudos_spend;
	private String badge_image_url;
	private String level;
	
	public employeeProfileModel(String name,String dept,String email,String image_url,int current_kudos,int kudos_spent,String badge_image_url, String level) {
		this.name = name;
		this.email = email;
		this.dept = dept;
		this.image_url = image_url;
		this.current_kudos = current_kudos;
		this.kudos_spend = kudos_spent;
		this.badge_image_url = badge_image_url;
		this.level = level;
 	}
	
	public String getName() {
		return name;
	}
	

}

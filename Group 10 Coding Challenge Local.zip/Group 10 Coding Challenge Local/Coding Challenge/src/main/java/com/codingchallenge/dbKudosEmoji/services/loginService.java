package com.codingchallenge.dbKudosEmoji.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.models.successLoginResponse;
import com.codingchallenge.dbKudosEmoji.utils.dbConnector;

@Service
public class loginService {

	static Logger logger = Logger.getLogger(loginService.class.getName());
	String url = "jdbc:mysql://localhost:3306/group10codingchallenge";
	String driver = "com.mysql.jdbc.Driver";
	private String username = "root";
	private String password = "root"; 
	
	
	
	
	public successLoginResponse login(String email) {

		Connection conn = null;
		try
	    {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully!");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection2();
			if (conn == null) {
				logger.info("Error Connecting!");
	
			}
			logger.info("Connected to DB!!");
	
			String query = "SELECT current_kudos FROM Employee WHERE email=" + "'"+ email+ "'";
			
			
			System.out.println(query);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			
		
			if(rs.next() == true) {
				int wallet = rs.getInt("current_kudos");
				return new successLoginResponse(wallet);
			}
			

	        st.close();


	      
	    }
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB!!");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return new successLoginResponse(-1);

	}
	
}
		

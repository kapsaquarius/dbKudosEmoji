package com.codingchallenge.dbKudosEmoji.models;

public class successLoginResponse {
	
	int wallet;
	
	public successLoginResponse(int wallet) {
		this.wallet = wallet;
	}
	
	public int getWallet() {
		return wallet;
	}

}

package com.codingchallenge.dbKudosEmoji.models;

public class successDeleteResponse {
	
	String success;
	
	public successDeleteResponse(String success) {
		this.success = success;
	}
	
	public String getStatus() {
		return success;
	}

}

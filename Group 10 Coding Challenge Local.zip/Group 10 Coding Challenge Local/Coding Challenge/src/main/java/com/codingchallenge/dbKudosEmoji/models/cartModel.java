package com.codingchallenge.dbKudosEmoji.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class cartModel {
	
	public String badge_id;
	public String name;
	public String image_url;
	public String level;
	public int kudos_points_required;
	
	public cartModel(String badge_id,String name,String image_url,String level,int kudos_points_required) {
		this.badge_id = badge_id;
		this.name = name;
		this.image_url = image_url;
		this.level = level;
		this.kudos_points_required = kudos_points_required;
		
	}
	

}
package com.codingchallenge.dbKudosEmoji.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;

import com.codingchallenge.dbKudosEmoji.models.badgeDetailsModel;
import com.codingchallenge.dbKudosEmoji.models.employeeModel;
import com.codingchallenge.dbKudosEmoji.models.successAddToCartModel;
import com.codingchallenge.dbKudosEmoji.utils.dbConnector;

@Service
public class marketplaceService {
	
	static Logger logger = Logger.getLogger(marketplaceService.class.getName());
	String url = "jdbc:mysql://localhost:3306/group10codingchallenge";
	String driver = "com.mysql.jdbc.Driver";
	private String username = "root";
	private String password = "root"; 
	
	
	
	public List<badgeDetailsModel> getBadgesByFilter(String[] filters,String email) {
		Connection conn = null;
		List<badgeDetailsModel> badges = new ArrayList<>();
		String query;
		try
	    {
			
			Class.forName(driver);
			logger.info("Driver Loaded Successfully");
			
			dbConnector dbconnect = new dbConnector(url,username,password);
			
			conn = dbconnect.getConnection2();
			if (conn == null) {
				logger.info("Error Connecting");

			}
			logger.info("Connected to DB");
			

			List<String> f = Arrays.asList(filters);
			int l = filters.length;
			
			if (f.contains("trending")) {
				query="SELECT Badge_Details.badge_id,Badge_Details.name,Badge_Details.image_url,Badge_Details.kudos_points_required,Badge_Details.level \r\n"
						+ "from Badge_Details,Badges_Bought \r\n"
						+ "where Badge_Details.badge_id = Badges_Bought.badge_id \r\n"
						+ "group by level\r\n"
						+ "order by count(*) desc\r\n"
						+ "limit 5;";
			}
			else if (f.contains("redeemable")) {			
				query = "SELECT * from Badge_Details where kudos_points_required <= (SELECT current_kudos from Employee where email="+"'"+email+"'"+")";	
			}
			else if (f.contains("all")) {				
				query = "select * from Badge_Details";			
			}
			else {
				
				if(l==1) {
					query = "SELECT * from Badge_Details where level in"+"("+"'"+filters[0]+"'"+")";	
				}
				else if(l==2) {
					query = "SELECT * from Badge_Details where level in"+"("+"'"+filters[0]+"'"+","+"'"+filters[1]+"'"+ ")";
				}
				else if(l==3) {
					query = "SELECT * from Badge_Details where level in"+"("+"'"+filters[0]+"'"+","+"'"+filters[1]+"'"+ ","+"'"+filters[2]+"'"+")";
				}
				else if(l==4) {
					query = "SELECT * from Badge_Details where level in"+"("+"'"+filters[0]+"'"+","+"'"+filters[1]+"'"+ ","+"'"+filters[2]+"'"+","+"'"+filters[3]+"'"+")";	
				}
				else if(l==5) {
					query = "SELECT * from Badge_Details where level in"+"("+"'"+filters[0]+"'"+","+"'"+filters[1]+"'"+ ","+"'"+filters[2]+"'"+","+"'"+filters[3]+"'"+","+"'"+filters[4]+"'"+")";
				}
				else {
					query = "select * from Badge_Details";
				}
				
				
			}
			
			
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			
	      
	        while (rs.next())
	        {
	        	String id = rs.getString("badge_id");
		        String name = rs.getString("name");
		        String imgUrl = rs.getString("image_url");
		        int pointsReq = rs.getInt("kudos_points_required");
		        String level =rs.getString("level");

		       
		        badges.add(new badgeDetailsModel(id, name,imgUrl,pointsReq, level));
		        
	     
	        }
	        
	        System.out.println(badges);
	        st.close();
	      
	      
	       
	    }
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				logger.info("Disconnected from DB");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return badges;
		
	}
	
	
	

}
